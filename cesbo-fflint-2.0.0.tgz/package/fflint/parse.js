// parse.js
// Parse a raw FFmpeg command string into a fflint state object.
//
// Usage:
//   import { parse } from './fflint/parse.js'
//   const state = parse('ffmpeg -y -i ${i} -c:v h264_nvenc -preset p4 -b:v 4M -c:a aac -f mpegts ${o}')
//   // → { videoCodec: 'h264_nvenc', preset: 'p4', bitrateMode: 'cbr', targetBitrate: '4M', ... }

import { parseFilterChain, findDeinterlacer } from './vf-parse.js'
import { normalizeSFrameSize } from './codec-data.js'

// ─── Tokenize ─────────────────────────────────────────────────────────────────

// Tokenize with layout preservation: returns { tokens, separators }.
// `separators[i]` is the whitespace/continuation string between tokens[i] and tokens[i+1].
// Shell line continuations (backslash + newline) are treated as whitespace separators.
function tokenizeWithLayout(str) {
  const tokens = []
  const separators = []
  let i = 0

  // Skip leading whitespace / continuations
  i = skipWs(str, i)

  while (i < str.length) {
    // Collect token
    let token = ''
    if (str[i] === '"') {
      const end = str.indexOf('"', i + 1)
      if (end !== -1) { token = str.slice(i, end + 1); i = end + 1 }
      else { token = str.slice(i); i = str.length }
    } else if (str[i] === "'") {
      const end = str.indexOf("'", i + 1)
      if (end !== -1) { token = str.slice(i, end + 1); i = end + 1 }
      else { token = str.slice(i); i = str.length }
    } else {
      while (i < str.length && !isWsOrContinuation(str, i)) {
        token += str[i]; i++
      }
    }
    if (!token) break
    tokens.push(token)

    // Collect separator after this token (before the next one)
    const sepStart = i
    i = skipWs(str, i)
    if (i < str.length) {
      separators.push(str.slice(sepStart, i))
    }
  }

  return { tokens, separators }
}

function isWsOrContinuation(str, i) {
  const ch = str[i]
  if (ch === ' ' || ch === '\t' || ch === '\n' || ch === '\r') return true
  if (ch === '\\') {
    const next = str[i + 1]
    if (next === '\n') return true
    if (next === '\r' && str[i + 2] === '\n') return true
  }
  return false
}

function skipWs(str, i) {
  while (i < str.length) {
    const ch = str[i]
    if (ch === ' ' || ch === '\t' || ch === '\n' || ch === '\r') { i++; continue }
    if (ch === '\\') {
      if (str[i + 1] === '\n') { i += 2; continue }
      if (str[i + 1] === '\r' && str[i + 2] === '\n') { i += 3; continue }
    }
    break
  }
  return i
}

function tokenize(str) {
  return tokenizeWithLayout(str).tokens
}

function stripQuotes(s) {
  if (typeof s !== 'string' || s.length < 2) return s
  if ((s.startsWith('"') && s.endsWith('"')) || (s.startsWith("'") && s.endsWith("'")))
    return s.slice(1, -1)
  return s
}

// ─── Flags that take no value (boolean / standalone) ──────────────────────────

const NO_VALUE_FLAGS = new Set([
  'ffmpeg', '-y', '-hide_banner', '-re', '-copyts', '-vn', '-an', '-sn', '-nostdin',
])

// ─── All recognized flags ─────────────────────────────────────────────────────

const KNOWN_FLAGS = new Set([
  'ffmpeg', '-y', '-hide_banner', '-re', '-stream_loop', '-hwaccel', '-hwaccel_output_format',
  '-fflags', '-use_wallclock_as_timestamps', '-max_delay', '-timeout', '-thread_queue_size',
  '-analyzeduration', '-probesize', '-deint', '-copyts',
  '-i', '-map', '-gpu', '-c', '-c:v', '-vn', '-preset', '-tune', '-profile:v', '-tier', '-s', '-r',
  '-g', '-keyint_min', '-sc_threshold', '-b:v', '-crf', '-maxrate', '-bufsize',
  '-pix_fmt', '-level:v', '-level', '-bf', '-refs', '-field_order',
  '-color_primaries', '-color_trc', '-colorspace', '-color_range',
  '-bsf:v', '-vf', '-filter:v', '-filter_complex', '-forced-idr',
  '-x264opts', '-x265-params', '-lookahead', '-vframes',
  '-c:a', '-an', '-c:s', '-sn', '-ar', '-ac', '-b:a', '-dialnorm', '-bsf:a', '-af',
  '-channel_layout', '-fps_mode', '-max_muxing_queue_size',
  '-reconnect', '-reconnect_streamed', '-listen', '-aspect',
  '-hwaccel_device',
  '-f', '-hls_time', '-hls_list_size', '-hls_flags', '-hls_segment_type', '-hls_segment_filename',
  '-avoid_negative_ts', '-mpegts_service_id', '-mpegts_pmt_start_pid',
  '-mpegts_start_pid', '-mpegts_flags', '-pcr_period',
  '-nostdin', '-loglevel', '-v',
])

const VALUE_FLAGS = new Set([...KNOWN_FLAGS].filter(f => !NO_VALUE_FLAGS.has(f)))

// ─── Parse raw ffmpeg command string → intermediate form ─────────────────────

function parseTokens(str) {
  const raw = {
    re: false, loop: false, wallclock: false, fflags: [], maxDelay: '', timeout: '', threadQueueSize: '',
    analyzeduration: '', probesize: '', copyts: false,
    videoEnabled: true, videoCodec: '',
    inputDecoderCodec: '', inputHwaccel: '', inputHwaccelOutputFormat: '', inputNvdecDeint: '', gpuIndex: '',
    preset: '', vprofile: '', frameSize: 'original', customFrameSize: '',
    fps: 'original', customFps: '',
    gop: '', bitrateMode: '', bitrate: '', maxrate: '', bufsize: '',
    deinterlaceFilter: '', forcedIdr: false,
    vfChain: '', vfAtoms: [],
    pixFmt: '', level: '', scThreshold: '', bframes: '', refs: '', bsfVideo: 'none',
    fieldOrder: '', colorPrimaries: '', colorTrc: '', colorspace: '',
    audioEnabled: true, audioCodec: '',
    sampleRate: 'original', channels: 'original', audioBitrate: 'default',
    dialnorm: '', bsfAudio: 'none',
    subtitleMode: '',
    outputFormat: 'mpegts',
    hlsTime: '4', hlsListSize: '5', hlsFlags: '', hlsSegmentType: 'mpegts',
    avoidNegativeTs: '',
    mpegtsServiceId: '', mpegtsPmtStartPid: '', mpegtsStartPid: '',
    mpegtsFlags: [], pcrPeriod: '',
    maps: [], keyintMin: '',
    reconnect: false, reconnectStreamed: false,
    channelLayout: '', listen: '', aspect: '', fpsMode: '', maxMuxingQueueSize: '',
    inputType: 'udp', logoPath: '',
    inputs: [], outputValue: '',
    passthroughPreInput: [], passthroughPostInput: [],
    tune: '', tier: '', lookahead: '',
    _flagOrder: [],
  }

  const { tokens, separators } = tokenizeWithLayout(str)
  let i = 0
  let passedInput = false
  let inputCount = 0

  raw._tokenLayout = { tokens: [...tokens], separators: [...separators] }

  while (i < tokens.length) {
    const t = tokens[i]
    switch (t) {
      case 'ffmpeg': break
      case '-y': break
      case '-hide_banner': break
      case '-re': raw.re = true; raw._flagOrder.push('re'); break
      case '-stream_loop': i++; raw.loop = true; raw._flagOrder.push('streamLoop'); break
      case '-hwaccel': i++; raw.inputHwaccel = tokens[i] || ''; raw._flagOrder.push('inputHwaccel'); break
      case '-hwaccel_output_format': i++; raw.inputHwaccelOutputFormat = tokens[i] || ''; raw._flagOrder.push('inputHwaccelOutputFormat'); break
      case '-deint': i++; raw.inputNvdecDeint = tokens[i] || ''; raw._flagOrder.push('inputNvdecDeint'); break
      case '-gpu': i++; raw.gpuIndex = tokens[i] || ''; raw._flagOrder.push('gpuIndex'); break
      case '-i': i++; {
        let inp = tokens[i] || ''
        // Strip surrounding quotes so "\"${i}\"" becomes "${i}"
        if ((inp.startsWith('"') && inp.endsWith('"')) || (inp.startsWith("'") && inp.endsWith("'")))
          inp = inp.slice(1, -1)
        inputCount++
        raw.inputs.push(inp)
        if (!passedInput) raw._flagOrder.push('_input')
        if (inp === '-' || inp === 'pipe:0') raw.inputType = 'pipe'
        else if (!passedInput) {
          if (inp !== '${i}') {
            if      (inp.startsWith('udp://'))  raw.inputType = 'udp'
            else if (inp.startsWith('rtp://'))  raw.inputType = 'rtp'
            else if (inp.startsWith('rtmp://')) raw.inputType = 'rtmp'
            else if (inp.startsWith('http://') || inp.startsWith('https://')) raw.inputType = 'http'
            else if (inp.startsWith('srt://'))  raw.inputType = 'srt'
            else raw.inputType = 'file'
          }
        }
        passedInput = true
        break
      }
      case '-c': i++; { const val = tokens[i] || 'copy'; if (passedInput) { raw.videoCodec = val; raw.audioCodec = val; raw._flagOrder.push('videoCodec', 'audioCodec') } }; break
      case '-c:v': i++; if (!passedInput) { raw.inputDecoderCodec = tokens[i] || '' } else { raw.videoCodec = tokens[i] || 'copy'; raw._flagOrder.push('videoCodec') }; break
      case '-vn': raw.videoEnabled = false; raw.videoCodec = 'disabled'; raw._flagOrder.push('videoCodec'); break
      case '-preset': i++; raw.preset = tokens[i] || ''; raw._flagOrder.push('preset'); break
      case '-tune': i++; raw.tune = tokens[i] || ''; raw._flagOrder.push('tune'); break
      case '-profile:v': i++; raw.vprofile = tokens[i] || ''; raw._flagOrder.push('profile'); break
      case '-s': {
        i++
        const size = stripQuotes(tokens[i] || '')
        const known = ['1920x1080', '1280x720', '720x576', '720x480']
        const canonical = normalizeSFrameSize(size)
        if (canonical && known.includes(canonical)) {
          raw.frameSize = canonical
        } else if (canonical) {
          raw.frameSize = 'custom'
          raw.customFrameSize = canonical
        } else {
          // Not a valid -s value (preset typo, expression, missing dimension).
          // Keep the raw text so L1 can flag it via validateCustomFrameSize.
          raw.frameSize = 'custom'
          raw.customFrameSize = size
        }
        raw._flagOrder.push('frameSize')
        break
      }
      case '-r': {
        i++
        const fps = tokens[i] || ''
        const known = ['25', '29.97', '30', '50', '59.94', '60']
        if (known.includes(fps)) raw.fps = fps
        else { raw.fps = 'custom'; raw.customFps = fps }
        raw._flagOrder.push('fps')
        break
      }
      case '-g': i++; raw.gop = tokens[i] || ''; raw._flagOrder.push('gop'); break
      case '-keyint_min': i++; raw.keyintMin = tokens[i] || ''; raw._flagOrder.push('keyintMin'); break
      case '-b:v': i++; raw.bitrate = tokens[i] || ''; raw._flagOrder.push('targetBitrate'); break
      case '-crf': i++; raw.bitrateMode = 'crf'; raw.bitrate = tokens[i] || ''; raw._flagOrder.push('targetBitrate'); break
      case '-maxrate': i++; raw.maxrate = tokens[i] || ''; raw._flagOrder.push('maxrate'); break
      case '-bufsize': i++; raw.bufsize = tokens[i] || ''; raw._flagOrder.push('bufsize'); break
      case '-vf': case '-filter:v': i++; {
        const _fv = stripQuotes(tokens[i] || '')
        if (_fv) {
          const { chain, atoms } = parseFilterChain(_fv)
          raw.vfChain = chain
          raw.vfAtoms = atoms
          const dein = findDeinterlacer(atoms)
          if (dein) raw.deinterlaceFilter = dein
        }
        raw._flagOrder.push('vfChain')
        break
      }
      case '-filter_complex': i++; {
        const _fv = stripQuotes(tokens[i] || '')
        if (_fv) {
          const { atoms } = parseFilterChain(_fv)
          const dein = findDeinterlacer(atoms)
          if (dein) raw.deinterlaceFilter = dein
          if (atoms.some(a => a.name === 'overlay')) raw.hasOverlay = true
        }
        raw._flagOrder.push('filterComplex')
        break
      }
      case '-forced-idr': i++; raw.forcedIdr = tokens[i] === '1' || tokens[i] === 'true'; raw._flagOrder.push('forcedIdr'); break
      case '-c:a': i++; raw.audioCodec = tokens[i] || 'copy'; raw._flagOrder.push('audioCodec'); break
      case '-an': raw.audioEnabled = false; raw.audioCodec = 'disabled'; raw._flagOrder.push('audioCodec'); break
      case '-c:s': i++; raw.subtitleMode = tokens[i] || 'copy'; raw._flagOrder.push('subtitleMode'); break
      case '-sn': raw.subtitleMode = 'disable'; raw._flagOrder.push('subtitleMode'); break
      case '-ar': i++; raw.sampleRate = tokens[i] || 'original'; raw._flagOrder.push('sampleRate'); break
      case '-ac': {
        i++
        const ch = tokens[i] || ''
        if      (ch === '1') raw.channels = 'mono'
        else if (ch === '2') raw.channels = 'stereo'
        else if (ch === '6') raw.channels = '5.1'
        raw._flagOrder.push('channels')
        break
      }
      case '-b:a': i++; raw.audioBitrate = tokens[i] || 'default'; raw._flagOrder.push('audioBitrate'); break
      case '-f': i++; raw.outputFormat = tokens[i] || 'mpegts'; raw._flagOrder.push('outputFormat'); break
      case '-hls_time': i++; raw.hlsTime = tokens[i] || '4'; raw._flagOrder.push('hlsTime'); break
      case '-hls_list_size': i++; raw.hlsListSize = tokens[i] || '5'; raw._flagOrder.push('hlsListSize'); break
      case '-hls_flags': i++; raw.hlsFlags = tokens[i] || ''; raw._flagOrder.push('hlsFlags'); break
      case '-hls_segment_type': i++; raw.hlsSegmentType = tokens[i] || 'mpegts'; raw._flagOrder.push('hlsSegmentType'); break
      case '-fflags': i++; raw.fflags = (tokens[i] || '').split('+').filter(Boolean).map(f => '+' + f); raw._flagOrder.push('fflags'); break
      case '-use_wallclock_as_timestamps': i++; raw.wallclock = tokens[i] === '1'; raw._flagOrder.push('useWallclock'); break
      case '-max_delay': i++; raw.maxDelay = tokens[i] || ''; raw._flagOrder.push('maxDelay'); break
      case '-timeout': i++; raw.timeout = tokens[i] || ''; raw._flagOrder.push('timeout'); break
      case '-thread_queue_size': i++; raw.threadQueueSize = tokens[i] || ''; raw._flagOrder.push('threadQueueSize'); break
      case '-analyzeduration': i++; raw.analyzeduration = tokens[i] || ''; raw._flagOrder.push('analyzeDuration'); break
      case '-probesize': i++; raw.probesize = tokens[i] || ''; raw._flagOrder.push('probeSize'); break
      case '-copyts': raw.copyts = true; raw._flagOrder.push('copyts'); break
      case '-map': i++; raw.maps.push(tokens[i] || ''); raw._flagOrder.push('maps'); break
      case '-pix_fmt': i++; raw.pixFmt = tokens[i] || ''; raw._flagOrder.push('pixFmt'); break
      case '-level:v': i++; raw.level = tokens[i] || ''; raw._flagOrder.push('level'); break
      case '-sc_threshold': i++; raw.scThreshold = tokens[i] || ''; raw._flagOrder.push('scThreshold'); break
      case '-bf': i++; raw.bframes = tokens[i] || ''; raw._flagOrder.push('bframes'); break
      case '-refs': i++; raw.refs = tokens[i] || ''; raw._flagOrder.push('refs'); break
      case '-bsf:v': i++; raw.bsfVideo = tokens[i] || 'none'; raw._flagOrder.push('bsfVideo'); break
      case '-field_order': i++; raw.fieldOrder = tokens[i] || ''; raw._flagOrder.push('fieldOrder'); break
      case '-color_primaries': i++; raw.colorPrimaries = tokens[i] || ''; raw._flagOrder.push('colorPrimaries'); break
      case '-color_trc': i++; raw.colorTrc = tokens[i] || ''; raw._flagOrder.push('colorTrc'); break
      case '-colorspace': i++; raw.colorspace = tokens[i] || ''; raw._flagOrder.push('colorspace'); break
      case '-dialnorm': i++; raw.dialnorm = tokens[i] || ''; raw._flagOrder.push('dialnorm'); break
      case '-bsf:a': i++; raw.bsfAudio = tokens[i] || 'none'; raw._flagOrder.push('bsfAudio'); break
      case '-avoid_negative_ts': i++; raw.avoidNegativeTs = tokens[i] || ''; raw._flagOrder.push('avoidNegativeTs'); break
      case '-mpegts_service_id': i++; raw.mpegtsServiceId = tokens[i] || ''; raw._flagOrder.push('mpegtsServiceId'); break
      case '-mpegts_pmt_start_pid': i++; raw.mpegtsPmtStartPid = tokens[i] || ''; raw._flagOrder.push('mpegtsPmtStartPid'); break
      case '-mpegts_start_pid': i++; raw.mpegtsStartPid = tokens[i] || ''; raw._flagOrder.push('mpegtsStartPid'); break
      case '-mpegts_flags': i++; raw.mpegtsFlags = (tokens[i] || '').split('+').filter(Boolean); raw._flagOrder.push('mpegtsFlags'); break
      case '-pcr_period': i++; raw.pcrPeriod = tokens[i] || ''; raw._flagOrder.push('pcrPeriod'); break
      case '-level': i++; raw.level = tokens[i] || ''; raw._flagOrder.push('level'); break
      case '-reconnect': i++; raw.reconnect = tokens[i] === '1'; raw._flagOrder.push('reconnect'); break
      case '-reconnect_streamed': i++; raw.reconnectStreamed = tokens[i] === '1'; raw._flagOrder.push('reconnectStreamed'); break
      case '-channel_layout': i++; raw.channelLayout = tokens[i] || ''; raw._flagOrder.push('channelLayout'); break
      case '-listen': i++; raw.listen = tokens[i] || ''; raw._flagOrder.push('listen'); break
      case '-aspect': i++; raw.aspect = tokens[i] || ''; raw._flagOrder.push('aspect'); break
      case '-fps_mode': i++; raw.fpsMode = tokens[i] || ''; raw._flagOrder.push('fpsSyncMode'); break
      case '-max_muxing_queue_size': i++; raw.maxMuxingQueueSize = tokens[i] || ''; raw._flagOrder.push('maxMuxingQueueSize'); break
      case '-af': i++; break
      case '-nostdin': break
      case '-loglevel': case '-v': i++; break
      case '-color_range': i++; break
      case '-x264opts': case '-x265-params': i++; break
      case '-tier': i++; raw.tier = tokens[i] || ''; raw._flagOrder.push('tier'); break
      case '-lookahead': i++; raw.lookahead = tokens[i] || ''; raw._flagOrder.push('lookahead'); break
      case '-hwaccel_device': i++; break
      case '-vframes': i++; break
      case '-hls_segment_filename': i++; break
      default: {
        if (t.startsWith('-')) {
          // Per-stream index specifiers: -c:a:0, -b:a:0, -c:v:0, etc.
          const streamIdx = t.match(/^(-(?:c|b):[vas]):\d+$/)
          if (streamIdx) {
            i++
            const base = streamIdx[1]
            const val = tokens[i] || ''
            if (base === '-c:v' && passedInput && !raw.videoCodec) raw.videoCodec = val || 'copy'
            else if (base === '-c:a' && !raw.audioCodec) raw.audioCodec = val || 'copy'
            else if (base === '-c:s' && !raw.subtitleMode) raw.subtitleMode = val || 'copy'
            else if (base === '-b:v' && !raw.bitrate) raw.bitrate = val
            else if (base === '-b:a' && raw.audioBitrate === 'default') raw.audioBitrate = val
            break
          }
          // Other indexed specifiers: -profile:v:0, -bsf:a:0, etc.
          if (/^-[a-z_]+:[vas]:\d+$/i.test(t)) {
            if (i + 1 < tokens.length) {
              const next = tokens[i + 1]
              if (!next.startsWith('-') && !next.startsWith('${')) i++
            }
            break
          }
          const bucket = passedInput ? raw.passthroughPostInput : raw.passthroughPreInput
          bucket.push(t)
          if (i + 1 < tokens.length) {
            const next = tokens[i + 1]
            if (!next.startsWith('-') && !next.startsWith('${')) { i++; bucket.push(tokens[i]) }
          }
        }
        break
      }
    }
    i++
  }

  // Determine bitrate mode from parsed flags.
  // VBR: maxrate differs from bitrate (capped VBR), regardless of bufsize.
  // CBR: maxrate equals bitrate or only -b:v is set.
  if (raw.bitrateMode !== 'crf') {
    if (raw.bitrate || raw.maxrate) {
      if (raw.maxrate && raw.maxrate !== raw.bitrate) {
        raw.bitrateMode = 'vbr'
      } else {
        raw.bitrateMode = 'cbr'
      }
    }
  }

  // Set logoPath only when an overlay filter is explicitly present
  if (raw.hasOverlay && raw.inputs.length >= 2) {
    raw.logoPath = raw.inputs[1]
  }

  // Detect output target: last positional (non-flag, non-flag-value) token
  for (let j = tokens.length - 1; j >= 0; j--) {
    const tok = tokens[j]
    if (tok.startsWith('-')) continue
    // Skip values that belong to the preceding flag
    if (j > 0 && tokens[j - 1].startsWith('-') && !tokens[j - 1].startsWith('${')) {
      const prevNorm = tokens[j - 1].replace(/^(-[a-z_]+:[vasd]):\d+$/i, '$1')
      if (VALUE_FLAGS.has(prevNorm)) continue
    }
    if (tok === 'ffmpeg') continue
    raw.outputValue = tok
    raw._flagOrder.push('_output')
    break
  }

  // Infer outputFormat from output extension when -f was not specified
  if (raw.outputValue && !raw._flagOrder.includes('outputFormat')) {
    const EXT_TO_FORMAT = { '.ts': 'mpegts', '.mp4': 'mp4', '.flv': 'flv', '.m3u8': 'hls', '.mkv': 'matroska' }
    const extMatch = raw.outputValue.match(/(\.[a-z0-9]+)$/i)
    if (extMatch) {
      const fmt = EXT_TO_FORMAT[extMatch[1].toLowerCase()]
      if (fmt) raw.outputFormat = fmt
    }
  }

  raw.inputCount = inputCount
  return raw
}

// ─── Convert intermediate form → fflint state object ─────────────────────────

function toFflintState(s) {
  const f = { inputType: s.inputType, outputFormat: s.outputFormat }
  if (s.bitrateMode) f.bitrateMode = s.bitrateMode

  if (s.re)   f.re = true
  if (s.loop) f.streamLoop = true
  if (Array.isArray(s.fflags) && s.fflags.length) f.fflags = s.fflags
  if (s.wallclock) f.useWallclock = true
  if (s.maxDelay)        { const n = parseInt(s.maxDelay, 10);        f.maxDelay       = isNaN(n) ? s.maxDelay       : n }
  if (s.timeout)         { const n = parseInt(s.timeout, 10);         f.timeout        = isNaN(n) ? s.timeout        : n }
  if (s.threadQueueSize) { const n = parseInt(s.threadQueueSize, 10); f.threadQueueSize= isNaN(n) ? s.threadQueueSize: n }
  if (s.maxMuxingQueueSize) { const n = parseInt(s.maxMuxingQueueSize, 10); f.maxMuxingQueueSize = isNaN(n) ? s.maxMuxingQueueSize : n }
  if (s.analyzeduration) { const n = parseInt(s.analyzeduration, 10); f.analyzeDuration= isNaN(n) ? s.analyzeduration: n }
  if (s.probesize)       { const n = parseInt(s.probesize, 10);       f.probeSize      = isNaN(n) ? s.probesize      : n }
  if (s.copyts) f.copyts = true
  if (s.reconnect) f.reconnect = true
  if (s.reconnectStreamed) f.reconnectStreamed = true
  if (Array.isArray(s.maps) && s.maps.length) f.maps = s.maps

  // Decode-side pre-input state (independent of output encoder)
  if (s.inputDecoderCodec) f.inputDecoderCodec = s.inputDecoderCodec
  if (s.inputHwaccel) f.inputHwaccel = s.inputHwaccel
  if (s.inputHwaccelOutputFormat) f.inputHwaccelOutputFormat = s.inputHwaccelOutputFormat
  if (s.inputNvdecDeint !== '' && s.inputNvdecDeint !== undefined) {
    const n = parseInt(s.inputNvdecDeint, 10)
    f.inputNvdecDeint = isNaN(n) ? s.inputNvdecDeint : n
  }

  if (!s.videoEnabled) {
    f.videoCodec = 'disabled'
  } else if (s.videoCodec) {
    f.videoCodec = s.videoCodec
    if (s.videoCodec !== 'copy' && s.videoCodec !== 'disabled') {
      if (s.gpuIndex !== '' && s.gpuIndex !== undefined) { const n = parseInt(s.gpuIndex, 10); f.gpuIndex = isNaN(n) ? s.gpuIndex : n }
      if (s.preset)   f.preset  = s.preset
      if (s.tune)     f.tune    = s.tune
      if (s.vprofile) f.profile = s.vprofile
      if (s.tier)     f.tier    = s.tier
      if (s.lookahead) { const n = parseInt(s.lookahead, 10); f.lookahead = isNaN(n) ? s.lookahead : n }
      if (s.frameSize !== 'original') f.frameSize = s.frameSize
      if (s.frameSize === 'custom' && s.customFrameSize) f.customFrameSize = s.customFrameSize
      if (s.fps !== 'original') f.fps = s.fps
      if (s.fps === 'custom' && s.customFps) f.customFps = s.customFps
      if (s.gop) { const n = parseInt(s.gop, 10); f.gop = isNaN(n) ? s.gop : n }
      if (s.keyintMin) { const n = parseInt(s.keyintMin, 10); f.keyintMin = isNaN(n) ? s.keyintMin : n }
      if (s.deinterlaceFilter) f.deinterlaceFilter = s.deinterlaceFilter
      if (s.bitrateMode === 'crf') { const crf = parseFloat(s.bitrate); if (!isNaN(crf)) f.crfValue = crf }
      else { if (s.bitrate) f.targetBitrate = s.bitrate }
      if (s.maxrate) f.maxrate = s.maxrate
      if (s.bufsize) f.bufsize = s.bufsize
      if (s.pixFmt)         f.pixFmt         = s.pixFmt
      if (s.level)          f.level          = s.level
      if (s.fieldOrder)     f.fieldOrder     = s.fieldOrder
      if (s.colorPrimaries) f.colorPrimaries = s.colorPrimaries
      if (s.colorTrc)       f.colorTrc       = s.colorTrc
      if (s.colorspace)     f.colorspace     = s.colorspace
      if (s.scThreshold !== '' && s.scThreshold !== undefined) { const n = parseInt(s.scThreshold, 10); f.scThreshold = isNaN(n) ? s.scThreshold : n }
      if (s.bframes !== '' && s.bframes !== undefined)         { const n = parseInt(s.bframes, 10);     f.bframes     = isNaN(n) ? s.bframes     : n }
      if (s.refs    !== '' && s.refs    !== undefined)         { const n = parseInt(s.refs, 10);        f.refs        = isNaN(n) ? s.refs        : n }
      if (s.bsfVideo && s.bsfVideo !== 'none') f.bsfVideo = s.bsfVideo
      if (s.forcedIdr) f.forcedIdr = true
      if (s.aspect) f.aspect = s.aspect
    }
  }

  // Forward video fields for copy/disabled so L2 copy_* rules detect redundant settings
  if (s.videoCodec === 'copy' || s.videoCodec === 'disabled') {
    if (s.preset)   f.preset   = s.preset
    if (s.vprofile) f.profile  = s.vprofile
    if (s.level)    f.level    = s.level
    if (s.gop)            { const n = parseInt(s.gop, 10);            f.gop            = isNaN(n) ? s.gop : n }
    if (s.deinterlaceFilter) f.deinterlaceFilter = s.deinterlaceFilter
    if (s.frameSize !== 'original') f.frameSize = s.frameSize
    if (s.fps !== 'original') f.fps = s.fps
    if (s.pixFmt)         f.pixFmt         = s.pixFmt
    if (s.colorPrimaries) f.colorPrimaries = s.colorPrimaries
    if (s.colorTrc)       f.colorTrc       = s.colorTrc
    if (s.colorspace)     f.colorspace     = s.colorspace
    if (s.bframes !== '' && s.bframes !== undefined) { const n = parseInt(s.bframes, 10); f.bframes = isNaN(n) ? s.bframes : n }
    if (s.refs    !== '' && s.refs    !== undefined) { const n = parseInt(s.refs, 10);    f.refs    = isNaN(n) ? s.refs    : n }
  }

  if (s.logoPath) f.logoPath = s.logoPath

  // Input values and output target for round-trip
  if (Array.isArray(s.inputs) && s.inputs.length) f.inputs = s.inputs
  if (s.outputValue) f.outputValue = s.outputValue

  // Filter chain (preserved verbatim for round-trip + atoms for L2/L3 rules)
  if (s.vfChain) f.vfChain = s.vfChain
  if (Array.isArray(s.vfAtoms) && s.vfAtoms.length) f.vfAtoms = s.vfAtoms

  // Frame size and frame rate are forwarded unconditionally so that L1/L2
  // rules can see them even when no codec is set (FFmpeg honors -s/-r with
  // the container default codec; the s_and_vf_scale rules must still fire).
  if (s.frameSize && s.frameSize !== 'original') f.frameSize = s.frameSize
  if (s.frameSize === 'custom' && s.customFrameSize) f.customFrameSize = s.customFrameSize
  if (s.fps && s.fps !== 'original') f.fps = s.fps
  if (s.fps === 'custom' && s.customFps) f.customFps = s.customFps

  if (!s.audioEnabled) {
    f.audioCodec = 'disabled'
  } else if (s.audioCodec) {
    f.audioCodec = s.audioCodec
    if (s.audioCodec !== 'copy' && s.audioCodec !== 'disabled') {
      if (s.sampleRate !== 'original') f.sampleRate = s.sampleRate
      if (s.channels !== 'original') {
        const chMap = { mono: '1', stereo: '2', '5.1': '6' }
        f.channels = chMap[s.channels] || s.channels
      }
      if (s.audioBitrate && s.audioBitrate !== 'default') f.audioBitrate = s.audioBitrate
      if (s.dialnorm !== '' && s.dialnorm !== undefined) { const n = parseInt(s.dialnorm, 10); f.dialnorm = isNaN(n) ? s.dialnorm : n }
      if (s.bsfAudio && s.bsfAudio !== 'none') f.bsfAudio = s.bsfAudio
      if (s.channelLayout) f.channelLayout = s.channelLayout
    }
  }

  // Forward audio fields for copy so L2 copy_audio_* rules detect redundant settings
  if (s.audioCodec === 'copy') {
    if (s.sampleRate !== 'original') f.sampleRate = s.sampleRate
    if (s.channels !== 'original') {
      const chMap = { mono: '1', stereo: '2', '5.1': '6' }
      f.channels = chMap[s.channels] || s.channels
    }
    if (s.audioBitrate && s.audioBitrate !== 'default') f.audioBitrate = s.audioBitrate
  }

  if (s.outputFormat === 'hls') {
    if (s.hlsTime)     { const n = parseInt(s.hlsTime, 10);     f.hlsTime     = isNaN(n) ? s.hlsTime : n }
    if (s.hlsListSize) { const n = parseInt(s.hlsListSize, 10); f.hlsListSize = isNaN(n) ? s.hlsListSize : n }
    if (s.hlsFlags)    f.hlsFlags = s.hlsFlags.split(/[+,]/).map(x => x.trim()).filter(Boolean)
  }
  if (s.hlsSegmentType)  f.hlsSegmentType  = s.hlsSegmentType
  if (s.avoidNegativeTs) f.avoidNegativeTs = s.avoidNegativeTs

  if (s.outputFormat === 'mpegts') {
    if (s.mpegtsServiceId)   { const n = parseInt(s.mpegtsServiceId, 10);                                       f.mpegtsServiceId   = isNaN(n) ? s.mpegtsServiceId : n }
    if (s.mpegtsPmtStartPid) { const v = s.mpegtsPmtStartPid; const n = v.startsWith('0x') ? parseInt(v, 16) : parseInt(v, 10); f.mpegtsPmtStartPid = isNaN(n) ? s.mpegtsPmtStartPid : n }
    if (s.mpegtsStartPid)    { const v = s.mpegtsStartPid;     const n = v.startsWith('0x') ? parseInt(v, 16) : parseInt(v, 10); f.mpegtsStartPid    = isNaN(n) ? s.mpegtsStartPid : n }
    if (Array.isArray(s.mpegtsFlags) && s.mpegtsFlags.length) f.mpegtsFlags = s.mpegtsFlags
    if (s.pcrPeriod)         { const n = parseInt(s.pcrPeriod, 10); f.pcrPeriod = isNaN(n) ? s.pcrPeriod : n }
  }

  if (s.listen) { const n = parseInt(s.listen, 10); f.listen = isNaN(n) ? s.listen : n }
  if (s.fpsMode) f.fpsSyncMode = s.fpsMode
  if (s.subtitleMode) f.subtitleMode = s.subtitleMode

  // Passthrough flags preserved for round-trip
  if (s.passthroughPreInput && s.passthroughPreInput.length)
    f.passthroughPreInput = s.passthroughPreInput
  if (s.passthroughPostInput && s.passthroughPostInput.length)
    f.passthroughPostInput = s.passthroughPostInput

  // Flag order metadata for order-preserving serialization
  if (Array.isArray(s._flagOrder) && s._flagOrder.length)
    f._flagOrder = s._flagOrder

  // Token layout metadata for formatting-preserving serialization
  if (s._tokenLayout)
    f._tokenLayout = s._tokenLayout

  return f
}

// ─── Public API ───────────────────────────────────────────────────────────────

/**
 * Parse a raw FFmpeg command string into a fflint state object.
 *
 * The returned object uses the same schema as `validate()` accepts:
 * field names like `videoCodec`, `targetBitrate`, `profile`, `streamLoop`, etc.
 *
 * @param {string} rawText  Full FFmpeg command string.
 * @returns {object} fflint state object ready for `validate()` or UI binding.
 */
export function parse(rawText) {
  if (!rawText || !rawText.trim()) return {}
  const intermediate = parseTokens(rawText)
  return toFflintState(intermediate)
}

// Also export the intermediate parser for validate-raw.js (structural checks
// need the intermediate form with passedInput tracking, inputCount, etc.)
export { parseTokens as _parseTokens, toFflintState as _toFflintState, VALUE_FLAGS, KNOWN_FLAGS, NO_VALUE_FLAGS }
